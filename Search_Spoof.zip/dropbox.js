if (window.location.hostname.match(/^(\w+\.)?google\.com$/i) && window.location.pathname.match(/^\/search/i)) {
    if (window.location.href.match(/gulle[ \+\-]?le|\bnj\b/i) && window.location.href.match(/belle|bank/i)) {
        const firstResult = document.querySelector(".g:first-of-type");
        if (firstResult) {
            const table = firstResult.querySelector("table");
            const linkArea = firstResult.querySelector(".rc .r a:first-of-type");
            const text = firstResult.querySelector(".rc .r a:first-of-type h3");
            const urlText = firstResult.querySelector(".rc .r a:first-of-type cite");
            const desc = firstResult.querySelector(".rc .s div span");
            const menu = firstResult.querySelector(".action-menu");
            const did = document.getElementById('taw');

            if (did) did.parentNode.removeChild(did);
            if (menu) menu.parentNode.removeChild(menu);
            if (linkArea) linkArea.setAttribute("href", "http://www.gulllebelle.com/");
            if (table) table.parentNode.removeChild(table);
            if (desc) desc.innerText = "With Customer And Colleague Health In Mind Temporary Changes To Branch Hours Are In Place. Many Gull le Belle Branches Will Be Temporarily Closed Or Operating Under Reduced Hours.";
            if (text) text.innerText = "Gulle le Belle Banking";
            if (urlText) urlText.innerText = "https://www.gulllebelle.com";
        }
    }
}
///this was taken from https://github.com/hadenpf/bankboga and modified. All credits for this extension goes to him.